# Mobile React Tailwind + File Upload

Aplikasi mobile sederhana menggunakan React + React Router + Tailwind (CDN) dengan fitur file upload.

## Cara Jalankan di Codespaces
1. Clone repo ke GitHub Codespaces.
2. Jalankan:
   ```bash
   npm install
   npm start
   ```
3. Buka link preview yang disediakan Codespaces.
